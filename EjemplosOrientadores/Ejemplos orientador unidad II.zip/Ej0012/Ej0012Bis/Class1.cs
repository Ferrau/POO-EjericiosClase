﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ej0012;

namespace Ej0012Bis
{
    public class Class1 : ClaseBase
    {
        // Da un error de X no existe en el contexto actual porque
        // si bien Class1 es una subclase de ClaseBase,
        // Class1 se encuentra en un ensamblado distinto al que
        // está ClaseBase.
        // X=10
    }
}
