﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic
{
    public class PRODUCTO
    {
        private int codigobarra;

        public int CodigoBarra
        {
            get { return codigobarra; }
            set { codigobarra = value; }
        }

    }
}
