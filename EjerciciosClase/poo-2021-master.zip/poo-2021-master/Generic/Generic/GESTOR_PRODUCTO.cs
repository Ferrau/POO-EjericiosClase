﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic
{
    public class GESTOR_PRODUCTO : GESTOR<PRODUCTO>
    {
        public override int Borrar(PRODUCTO objeto)
        {
            throw new NotImplementedException();
        }

        public override int Editar(PRODUCTO objeto)
        {
            throw new NotImplementedException();
        }

        public override int Insertar(PRODUCTO objeto)
        {
            throw new NotImplementedException();
        }

        public override List<PRODUCTO> Listar()
        {
            throw new NotImplementedException();
        }
    }
}
