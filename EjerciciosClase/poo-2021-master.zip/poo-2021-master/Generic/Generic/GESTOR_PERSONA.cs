﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic
{
    public class GESTOR_PERSONA : GESTOR<PERSONA>
    {
        public override int Borrar(PERSONA objeto)
        {
            throw new NotImplementedException();
        }

        public override int Editar(PERSONA objeto)
        {
            throw new NotImplementedException();
        }

        public override int Insertar(PERSONA objeto)
        {
            throw new NotImplementedException();
        }

        public override List<PERSONA> Listar()
        {
            throw new NotImplementedException();
        }
    }
}
