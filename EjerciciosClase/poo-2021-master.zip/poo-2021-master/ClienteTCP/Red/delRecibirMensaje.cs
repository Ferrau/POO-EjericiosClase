﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Red
{
    public delegate void delRecibirMensaje(string origen, string mensaje);
}