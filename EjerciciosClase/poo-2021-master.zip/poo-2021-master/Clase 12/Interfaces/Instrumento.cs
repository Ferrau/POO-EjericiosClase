﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interfaces
{
    public abstract class Instrumento
    {
        protected string nombre;
    }
}